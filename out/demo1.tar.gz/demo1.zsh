#!/usr/bin/env zsh
demo1() {
  printf "\n\n This is an upgraded and folder isolated HEAD brew script!\n\n"
}
demo1 "$@"
